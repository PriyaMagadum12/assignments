let string='hello';
for(let i=string.length-1;i>=0;i--)
{
   
     string[i];
}
console.log(string);
