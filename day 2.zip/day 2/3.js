function arg(...a)
{
    result=arguments.length;
    console.log('argumnet are: '+a);
    console.log('total number of arguments passed: '+result )
}
arg(5,6,7,8);