(a,b) => a + b;
const a = 4;
const b = 2;
console.log(a+b);